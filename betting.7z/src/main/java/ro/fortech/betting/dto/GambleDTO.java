package ro.fortech.betting.dto;

public class GambleDTO {

	private Long matchId;
	
	private Long betId;

	public Long getMatchId() {
		return matchId;
	}

	public void setMatchId(Long matchId) {
		this.matchId = matchId;
	}

	public Long getBetId() {
		return betId;
	}

	public void setBetId(Long betId) {
		this.betId = betId;
	}

}
