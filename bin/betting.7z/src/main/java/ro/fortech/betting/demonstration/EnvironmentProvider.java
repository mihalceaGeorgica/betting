package ro.fortech.betting.demonstration;

public interface EnvironmentProvider {
	public String provideEnvironmentName();
}
